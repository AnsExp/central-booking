<?php
namespace CentralTickets\Constants;

final class PriceExtraConstants
{
    public const EXTRA      = 'extra';
    public const FLEXIBLE   = 'flexible';
    public const TERMS_CONDITIONS   = 'terms_conditions';
}
