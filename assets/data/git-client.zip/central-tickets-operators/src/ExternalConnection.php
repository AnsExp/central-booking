<?php
namespace CentralTickets;

use WP_Error;

final class ExternalConnection
{
    private function get_option()
    {
        $option = get_option('git_partner_delivery_url', []);
        if (is_array($option) && isset($option['delivery_url']) && isset($option['secret_key'])) {
            return $option;
        }
        return false;
    }

    private function send_data(string $action, array $data)
    {
        $option = $this->get_option();
        if (!$option) {
            return false;
        }
        $data['action'] = $action;
        $data['secret_key'] = $option['secret_key'];
        $response = wp_remote_post($option['delivery_url'], [
            'body' => json_encode($data),
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ]
        ]);
        if ($response instanceof WP_Error || $response['response']['code'] >= 300) {
            return [];
        }
        $array_response = json_decode(wp_remote_retrieve_body($response), true);
        return $array_response;
    }

    public function get_zones(): array
    {
        $response = $this->send_data('get_zones', []);
        if ($response === false) {
            return [];
        }
        return $response;
    }

    public function get_transports(): array
    {
        $response = $this->send_data('get_transports', []);
        if ($response === false) {
            return [];
        }
        return $response;
    }

    public function get_transports_for_booking(
        string $date_trip,
        string $schedule,
        string $name_zone_origin,
        string $name_zone_destiny
    ): array {
        $response = $this->send_data('get_transport_for_booking', [
            'schedule' => $schedule,
            'date_trip' => $date_trip,
            'name_zone_origin' => $name_zone_origin,
            'name_zone_destiny' => $name_zone_destiny
        ]);
        if ($response === false) {
            return [];
        }
        return $response;
    }

    public function check_availability_transport(
        string $date_trip,
        int $route_id,
        int $transport_id,
        int $passengers,
    ) {
        $response = $this->send_data('check_availability_transport', [
            'date_trip' => $date_trip,
            'route_id' => $route_id,
            'transport_id' => $transport_id,
            'passengers' => $passengers,
        ]);
        if ($response === false) {
            return false;
        }
        return $response['available'] ?? false;
    }

    public function get_transport(int $id)
    {
        $response = $this->send_data('get_transport', ['transport_id' => $id]);
        if ($response === false) {
            return null;
        }
        return $response;
    }

    public function get_products(): array
    {
        $response = $this->send_data('get_products', []);
        if ($response === false) {
            return [];
        }
        return $response;
    }

    public function get_product(int $id): array
    {
        $response = $this->send_data('get_product', ['product_id' => $id]);
        if ($response === false) {
            return [];
        }
        return $response;
    }

    public function get_routes()
    {
        $response = $this->send_data('get_routes', []);
        if ($response === false) {
            return [];
        }
        return $response;
    }

    public function get_route(int $id)
    {
        $response = $this->send_data('get_route', ['route_id' => $id]);
        if ($response === false) {
            return null;
        }
        return $response;
    }

    public function send_ticket_data(array $data)
    {
        $response = $this->send_data('send_ticket_data', $data);
        if ($response === false) {
            return null;
        }
        return $response;
    }
}
