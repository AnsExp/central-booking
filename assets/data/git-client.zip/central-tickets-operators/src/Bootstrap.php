<?php
namespace CentralTickets;

use CentralTickets\Admin\Settings\SettingsDashboard;
use CentralTickets\Admin\Tables\TableRoutes;
use CentralTickets\Admin\Tables\TableTransports;

final class Bootstrap
{
    private static bool $loaded = false;
    private static ?Bootstrap $instance = null;

    private function __construct()
    {
    }

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function init()
    {
        if (self::$loaded) {
            return;
        }
        self::$loaded = true;
        self::get_instance()->init_admin_menu();
        self::get_instance()->init_woocommerce_integration();
    }

    private function init_admin_menu()
    {
        add_action('admin_menu', function () {
            wp_enqueue_style(
                'icons-bootstrap',
                'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css',
                [],
                '5.3.0',
                'all'
            );
            wp_enqueue_style(
                'git-admin-dashboard',
                CENTRAL_TICKETS_URL . '/assets/css/admin-dashboard.css',
                [],
                '1.0',
                'all'
            );
            wp_enqueue_script(
                'git-admin-dashboard',
                CENTRAL_TICKETS_URL . '/assets/js/components/table-component.js',
                ['jquery'],
                '1.0',
                []
            );
            if (current_user_can('manage_options')) {
                add_menu_page(
                    'Central Tickets (Cliente)',
                    'Central Tickets (Cliente)',
                    'manage_options',
                    'central_tickets_operators',
                    function () {
                        (new SettingsDashboard())->display();
                    },
                    'dashicons-tickets',
                    6
                );
                add_submenu_page(
                    'central_tickets_operators',
                    'Transportes',
                    'Transportes',
                    'manage_options',
                    'git_transports',
                    function () {
                        (new TableTransports())->display();
                    },
                    6
                );
                add_submenu_page(
                    'central_tickets_operators',
                    'Rutas',
                    'Rutas',
                    'manage_options',
                    'git_routes',
                    function () {
                        (new TableRoutes())->display();
                    },
                    6
                );
            }
        });
    }

    private function init_woocommerce_integration()
    {
        add_filter('product_type_selector', function ($types) {
            $types['operator_external'] = 'Producto operable externo';
            return $types;
        });
        add_action('woocommerce_loaded', function () {
            if (class_exists('WC_Product')) {
                require_once CENTRAL_TICKETS_DIR . '/includes/woocommerce/git-hooks-woocommerce.php';
                require_once CENTRAL_TICKETS_DIR . '/includes/woocommerce/git-class-product-form.php';
                require_once CENTRAL_TICKETS_DIR . '/includes/woocommerce/git-class-passenger-form.php';
                require_once CENTRAL_TICKETS_DIR . '/includes/woocommerce/wc-class-product-operator-external.php';
                require_once CENTRAL_TICKETS_DIR . '/includes/woocommerce/single-product/git-class-form-product.php';
                require_once CENTRAL_TICKETS_DIR . '/includes/woocommerce/single-product/git-class-form-product-route.php';
                require_once CENTRAL_TICKETS_DIR . '/includes/woocommerce/single-product/git-class-form-product-transport.php';
                require_once CENTRAL_TICKETS_DIR . '/includes/woocommerce/single-product/git-class-form-product-passenger.php';
                require_once CENTRAL_TICKETS_DIR . '/includes/woocommerce/single-product/git-class-form-product-not-available.php';
            }
        });
    }
}
