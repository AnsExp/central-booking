<?php
namespace CentralTickets\Admin\Settings;

use CentralTickets\Components\Component;

if (!defined('ABSPATH')) {
    exit;
}

final class SettingsDashboard implements Component
{
    private array $tabs;
    private string $current_tab;

    public function __construct()
    {
        $this->current_tab = $_GET['tab'] ?? 'operator_external';
        $this->tabs = $this->get_available_tabs();
    }

    public function display()
    {
        echo $this->compact();
    }

    public function compact()
    {
        wp_enqueue_script(
            'central-tickets-settings-clients',
            CENTRAL_TICKETS_URL . '/assets/js/admin/settings-form.js',
        );
        ob_start();
        ?>
        <div class="wrap">
            <h1>Central Tickets (Operador)</h1>
            <div class="notice notice-info" style="padding:16px; margin-bottom:16px;">
                <h2 style="margin-top:0;">Central Tickets - Versión del Plugin</h2>
                <p>
                    <strong>Versión actual:</strong> 1.0
                </p>
                <p style="color:#666;">
                    Última actualización: <?= git_date_format(date('Y-m-d', filemtime(__FILE__))); ?>
                </p>
            </div>
            <?php $this->render_tab_navigation(); ?>
            <?php $this->render_current_tab_content() ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private function get_available_tabs()
    {
        return [
            'operator_external' => [
                'title' => 'Cliente Externo',
                'callback' => fn() => (new SettingsOperatorExternal)->display()
            ]
        ];
    }

    private function render_tab_navigation(): void
    {
        echo '<nav class="nav-tab-wrapper">';

        foreach ($this->tabs as $tab_key => $tab_data) {
            $url = add_query_arg([
                'page' => $_GET['page'] ?? 'git_settings',
                'tab' => $tab_key
            ], admin_url('admin.php'));

            $active_class = $this->current_tab === $tab_key ? 'nav-tab-active' : '';

            printf(
                '<a href="%s" class="nav-tab %s">%s</a>',
                esc_url($url),
                esc_attr($active_class),
                esc_html($tab_data['title'])
            );
        }

        echo '</nav>';
    }

    private function render_current_tab_content(): void
    {
        if (isset($this->tabs[$this->current_tab])) {
            $callback = $this->tabs[$this->current_tab]['callback'];

            if (is_callable($callback)) {
                call_user_func($callback);
            }
        } else {
            echo '<div class="git-notice error"><p>' .
                esc_html__('Pestaña no encontrada.', 'central-tickets') .
                '</p></div>';
        }
    }
}
