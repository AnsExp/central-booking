<?php
namespace CentralTickets\Admin\Settings;

use CentralTickets\Components\Displayer;
use CentralTickets\Components\TextareaComponent;

final class SettingsOperatorExternal implements Displayer
{
    public function display()
    {
        $operator_code_text_area = new TextareaComponent('operator_code');
        $operator_code_text_area->set_attribute('cols', '75');
        $operator_code_text_area->set_attribute('rows', '10');
        $operator_code_text_area->set_required(true);
        ?>
        <div class="wrap">
            <form method="post" action="<?= esc_url(admin_url('admin-ajax.php?action=git_submit_operator_code')) ?>">
                <table class="form-table">
                    <tr>
                        <th>
                            <?= $operator_code_text_area->get_label('API Key')->display() ?>
                        </th>
                        <td>
                            <?= $operator_code_text_area->display() ?>
                        </td>
                    </tr>
                </table>
                <input type="submit" class="button button-primary" value="Registrarse">
            </form>
        </div>
        <?php
    }
}
