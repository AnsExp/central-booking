<?php
namespace CentralTickets\Admin\Tables;

use CentralTickets\Components\Displayer;
use CentralTickets\ExternalConnection;

final class TableRoutes implements Displayer
{
    public function display()
    {
        $connector = new ExternalConnection();
        $routes = $connector->get_routes();
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Mis Rutas</h1>
            <div class="notice notice-info is-dismissible">
                <p>Estos son todos tus rutas registrados en el sistema GIT principal.</p>
            </div>
            <div style="overflow-x: auto; max-width: 1100px;">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th scope="col" style="width: 400px;">Origen - Destino</th>
                            <th scope="col" style="width: 100px;">Tipo</th>
                            <th scope="col" style="width: 100px;">Hora de salida</th>
                            <th scope="col" style="width: 100px;">Duración</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($routes as $route): ?>
                            <tr>
                                <td>
                                    <span style="display: flex; align-items: center; gap: 0.5rem;">
                                        <i class="bi bi-geo"></i>
                                        <span><?= esc_html($route['origin']['name']) ?></span>
                                        <i class="bi bi-arrow-right"></i>
                                        <span><?= esc_html($route['destiny']['name']) ?></span>
                                    </span>
                                    <div class="row-actions visible">
                                        <span class="edit">
                                            ID: <?= esc_html($route['id']) ?>
                                        </span>
                                        <span>|</span>
                                        <span class="edit">
                                            <a href="#transport-container-<?= $route['id'] ?>" class="git-row-action-link"
                                                data-route="<?= esc_attr($route['id']) ?>">
                                                Transportes (<?= count($route['transports']) ?>)
                                            </a>
                                        </span>
                                    </div>
                                </td>
                                <td><?= esc_html(git_get_text_by_type($route['type'])) ?></td>
                                <td><?= git_time_format($route['departure_time']) ?></td>
                                <td><?= git_duration_format($route['duration_trip']) ?></td>
                            </tr>
                            <tr id="actions-container-<?= $route['id'] ?>" class="git-row-actions">
                                <td colspan="4">
                                    <div id="transport-container-<?= $route['id'] ?>" class="git-item-container hidden"
                                        data-parent="#actions-container-<?= $route['id'] ?>">
                                        <?php foreach ($route['transports'] as $transport): ?>
                                            <div class="git-item">
                                                <?= esc_html($transport['nicename']) ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }
}