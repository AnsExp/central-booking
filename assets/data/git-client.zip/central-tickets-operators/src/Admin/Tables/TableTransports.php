<?php
namespace CentralTickets\Admin\Tables;

use CentralTickets\Components\Constants\ListConstants;
use CentralTickets\Components\Displayer;
use CentralTickets\Components\ListComponent;
use CentralTickets\ExternalConnection;

final class TableTransports implements Displayer
{
    public function display()
    {
        $connector = new ExternalConnection();
        $transports = $connector->get_transports();
        usort($transports, function ($a, $b) {
            return strcmp($a['nicename'], $b['nicename']);
        });
        ?>
        <div class="wrap" style="overflow-x: auto; max-width: 1100px;">
            <h1 class="wp-heading-inline">Mis Transportes</h1>
            <div class="notice notice-info is-dismissible">
                <p>Estos son todos tus transportes registrados en el sistema GIT principal.</p>
            </div>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th scope="col" style="width: 400px;">Nombre</th>
                        <th scope="col" style="width: 100px;">Código</th>
                        <th scope="col" style="width: 100px;">Capacidad</th>
                        <th scope="col" style="width: 100px;">Alias</th>
                        <th scope="col" style="width: 100px;">Tipo</th>
                        <th scope="col" style="width: 100px;">Disponibilidad</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transports as $transport): ?>
                        <tr>
                            <td>
                                <span>
                                    <?= esc_html($transport['nicename']) ?>
                                </span>
                                <div class="row-actions visible">
                                    <span>ID: <?= esc_html($transport['id']) ?></span>
                                    <span> | </span>
                                    <span class="edit">
                                        <a class="git-row-action-link" href="#routes-container-<?= $transport['id'] ?>">Rutas
                                            (<?= count($transport['routes']) ?>)</a>
                                    </span>
                                    <span> | </span>
                                    <span class="edit">
                                        <a class="git-row-action-link" href="#services-container-<?= $transport['id'] ?>">Servicios
                                            (<?= count($transport['services']) ?>)</a>
                                    </span>
                                </div>
                            </td>
                            <td><?= esc_html($transport['code']) ?></td>
                            <td><?= esc_html($transport['capacity']) ?></td>
                            <td>
                                <?php
                                $list_component = new ListComponent(ListConstants::UNORDER);
                                $list_component->styles->set('list-style-type', 'square');
                                $list_component->styles->set('margin', '0');
                                foreach ($transport['alias'] as $alias) {
                                    $list_component->add_item($alias);
                                }
                                $list_component->display();
                                ?>
                            </td>
                            <td><?= esc_html($transport['type']['display']) ?></td>
                            <td><?= $transport['available'] ? 'Disponible' : 'No disponible' ?></td>
                            </td>
                        </tr>
                        <tr id="actions-container-<?= $transport['id'] ?>" class="git-row-actions">
                            <td colspan="5">
                                <div id="routes-container-<?= $transport['id'] ?>" class="git-item-container hidden"
                                    data-parent="#actions-container-<?= $transport['id'] ?>">
                                    <?php foreach ($transport['routes'] as $route): ?>
                                        <div class="git-item">
                                            <table style="border-spacing: 20px 3px; border-collapse: separate;">
                                                <tr>
                                                    <td><b>Origen:</b></td>
                                                    <td><?= esc_html($route['origin']['name']) ?></td>
                                                </tr>
                                                <tr>
                                                    <td><b>Destino:</b></td>
                                                    <td><?= esc_html($route['destiny']['name']) ?></td>
                                                </tr>
                                                <tr>
                                                    <td><b>Hora:</b></td>
                                                    <td><?= git_time_format($route['departure_time']) ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div id="services-container-<?= $transport['id'] ?>" class="git-item-container hidden"
                                    data-parent="#actions-container-<?= $transport['id'] ?>">
                                    <?php foreach ($transport['services'] as $service): ?>
                                        <div class="git-item">
                                            <?= esc_html($service['name']) ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}
