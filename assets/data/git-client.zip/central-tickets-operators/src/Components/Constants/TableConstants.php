<?php
namespace CentralTickets\Components\Constants;

final class TableConstants
{
    public const HEAD = 'head';
    public const BODY = 'body';
    public const FOOT = 'foot';
}
