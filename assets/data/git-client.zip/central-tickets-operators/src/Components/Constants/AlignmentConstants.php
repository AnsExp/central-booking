<?php
namespace CentralTickets\Components\Constants;

class AlignmentConstants
{
    public const LEFT = 'left';
    public const CENTER = 'center';
    public const RIGHT = 'right';
}