<?php
namespace CentralTickets\Components\Constants;

class ButtonActionConstants
{
    public const RESET = 'reset';
    public const BUTTON = 'button';
    public const SUBMIT = 'submit';
}
