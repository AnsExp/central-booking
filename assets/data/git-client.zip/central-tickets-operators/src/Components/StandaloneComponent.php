<?php
namespace CentralTickets\Components;


class StandaloneComponent extends BaseComponent
{
}
