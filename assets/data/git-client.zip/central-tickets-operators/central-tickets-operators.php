<?php
/**
 * Plugin Name: GIT Cliente
 * Description: Conector a un sistema GIT Central
 * Version: 1.0
 * Author: AnsExp
 * Author URI: https://github.com/AnsExp
 * License: GPL2
 * Requires Plugins: woocommerce
 * Requires PHP: 8.1.0
 */

defined('ABSPATH') || exit;

if (!defined('CENTRAL_TICKETS_DIR')) {
    define('CENTRAL_TICKETS_DIR', plugin_dir_path(__FILE__));
}

if (!defined('CENTRAL_TICKETS_URL')) {
    define('CENTRAL_TICKETS_URL', plugin_dir_url(__FILE__));
}

require_once 'vendor/autoload.php';

CentralTickets\Bootstrap::init();

require_once 'includes/git-functions-hooks.php';
require_once 'includes/git-functions-utils.php';
