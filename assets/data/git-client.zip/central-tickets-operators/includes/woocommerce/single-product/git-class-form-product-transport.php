<?php
namespace CentralTickets\WooCommerce;

use CentralTickets\Components\Component;
use CentralTickets\Components\CounterComponent;
use CentralTickets\Constants\TypeWayConstants;
use CentralTickets\Constants\PriceExtraConstants;
use CentralTickets\Constants\PassengerConstants;

class FormProductTransport implements Component
{
    public function __construct(private array $product)
    {
    }

    public function compact()
    {
        $counter_rpm = new CounterComponent();
        $counter_kid = new CounterComponent();
        $counter_extra = new CounterComponent();
        $counter_standard = new CounterComponent();
        $prices = $this->product['prices'];
        $type_way = $this->product['type_way'];
        $type_transport = $this->product['type_transport'];
        $maximum_extras = $this->product['maximum_extras'];
        $maximum_persons = $this->product['maximum_persons'];

        $id_button_next = 'button_next_' . rand();
        $id_button_prev = 'button_prev_' . rand();
        $id_origin_label_goes = 'origin_label_goes_' . rand();
        $id_destiny_label_goes = 'destiny_label_goes_' . rand();
        $id_total_amount_label = 'total_amount_label_' . rand();
        $id_date_trip_label_goes = 'date_trip_label_goes_' . rand();
        $id_origin_label_returns = 'origin_label_returns_' . rand();
        $id_services_amount_label = 'services_amount_label_' . rand();
        $id_subtotal_amount_label = 'subtotal_amount_label_' . rand();
        $id_destiny_label_returns = 'destiny_label_returns_' . rand();
        $id_date_trip_label_returns = 'date_trip_label_returns_' . rand();
        $id_transports_container_goes = 'transports_container_goes_' . rand();
        $id_transports_container_returns = 'transports_container_returns_' . rand();
        $id_transports_options_container_goes = 'transports_options_container_goes_' . rand();
        $id_transports_options_container_returns = 'transports_options_container_returns_' . rand();

        wp_enqueue_script(
            'pane-form-transport',
            CENTRAL_TICKETS_URL . '/assets/js/client/product/pane-form-transport.js',
            [],
            null,
        );

        wp_localize_script(
            'pane-form-transport',
            'dataTransport',
            [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'hookFetchTransports' => 'git_fetch_transports',
                'hookCheckAvailability' => 'git_check_availability_for_passengers',
                'typeTransport' => $type_transport,
                'transportParent' => $this->product['id_transport_parent'],
                'prices' => $prices,
                'issues' => [
                    PassengerConstants::KID => '',
                    PassengerConstants::RPM => '',
                    PassengerConstants::STANDARD => '',
                    PriceExtraConstants::EXTRA => '',
                    PriceExtraConstants::FLEXIBLE => '',
                    PriceExtraConstants::TERMS_CONDITIONS => '',
                ],
                'maximum_extras' => $maximum_extras,
                'maximum_persons' => $maximum_persons,
                'elements' => [
                    'idButtonNext' => $id_button_next,
                    'idButtonPrev' => $id_button_prev,
                    'idOriginLabelGoes' => $id_origin_label_goes,
                    'idDestinyLabelGoes' => $id_destiny_label_goes,
                    'idDateTripLabelGoes' => $id_date_trip_label_goes,
                    'idOriginLabelReturns' => $id_origin_label_returns,
                    'idDestinyLabelReturns' => $id_destiny_label_returns,
                    'idDateTripLabelReturns' => $id_date_trip_label_returns,
                    'idTransportsContainerGoes' => $id_transports_container_goes,
                    'idTransportsContainerReturns' => $id_transports_container_returns,
                    'idTransportsOptionsContainerGoes' => $id_transports_options_container_goes,
                    'idTransportsOptionsContainerReturns' => $id_transports_options_container_returns,
                    'idTotalAmountLabel' => $id_total_amount_label,
                    'idServicesAmountLabel' => $id_services_amount_label,
                    'idSubtotalAmountLabel' => $id_subtotal_amount_label,
                    'idCounters' => [
                        'idRPM' => $counter_rpm->id,
                        'idKid' => $counter_kid->id,
                        'idExtra' => $counter_extra->id,
                        'idStandard' => $counter_standard->id,
                    ]
                ]
            ]
        );
        ob_start();
        ?>
        <div id="git-form-product-transport" style="display: none;">
            <div id="<?= $id_transports_container_goes ?>">
                <div class="third-container">
                    <span class="right fw-medium" id="<?= $id_origin_label_goes ?>"></span>
                    <span class="center fw-medium" id="<?= $id_date_trip_label_goes ?>"></span>
                    <span class="left fw-medium" id="<?= $id_destiny_label_goes ?>"></span>
                </div>
                <div id="<?= $id_transports_options_container_goes ?>" class="option-container">
                </div>
            </div>
            <?php if ($type_way !== TypeWayConstants::ONE_WAY): ?>
                <div id="<?= $id_transports_container_returns ?>">
                    <div class="third-container">
                        <span class="right fw-medium" id="<?= $id_origin_label_returns ?>"></span>
                        <span class="center fw-medium" id="<?= $id_date_trip_label_returns ?>"></span>
                        <span class="left fw-medium" id="<?= $id_destiny_label_returns ?>"></span>
                    </div>
                    <div id="<?= $id_transports_options_container_returns ?>" class="option-container">
                    </div>
                </div>
            <?php endif; ?>

            <ul class="nav nav-tabs m-0" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="standard-tab" data-bs-toggle="tab" data-bs-target="#standard-tab-pane"
                        type="button" role="tab" aria-controls="standard-tab-pane" aria-selected="true">Estándar</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="reduce-tab" data-bs-toggle="tab" data-bs-target="#reduce-tab-pane"
                        type="button" role="tab" aria-controls="reduce-tab-pane" aria-selected="false">Reducido</button>
                </li>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div id="standard-tab-pane" class="tab-pane fade show active" role="tabpanel" aria-labelledby="standard-tab"
                    tabindex="0">
                    <?php
                    $this->extra_component(
                        'Tickets — $' . $prices[PassengerConstants::STANDARD],
                        PassengerConstants::STANDARD,
                        $counter_standard
                    );
                    $this->extra_component(
                        'Extras — $' . $prices[PriceExtraConstants::EXTRA],
                        PriceExtraConstants::EXTRA,
                        $counter_extra
                    );
                    ?>
                </div>
                <div id="reduce-tab-pane" class="tab-pane fade" role="tabpanel" aria-labelledby="reduce-tab" tabindex="0">
                    <?php
                    $this->extra_component(
                        'Niño — $' . $prices[PassengerConstants::KID],
                        PassengerConstants::KID,
                        $counter_kid
                    );
                    $this->extra_component(
                        'Movilidad Reducida — $' . $prices[PassengerConstants::RPM],
                        PassengerConstants::RPM,
                        $counter_rpm
                    );
                    ?>
                </div>
            </div>
            <hr class="m-0">
            <div class="d-flex justify-content-between align-items-center p-3">
                <b>Subtotal:</b>
                <b id="<?= $id_subtotal_amount_label ?>" class="text-center" style="width: 100px">$0</b>
            </div>
            <div class="d-flex justify-content-between align-items-center p-3">
                <b>Servicios:</b>
                <b id="<?= $id_services_amount_label ?>" class="text-center" style="width: 100px">$0</b>
            </div>
            <hr class="m-0">
            <div class="d-flex justify-content-between align-items-center p-3">
                <b>Total:</b>
                <b id="<?= $id_total_amount_label ?>" class="text-center" style="width: 100px">$0</b>
            </div>
            <button id="<?= $id_button_prev ?>" type="button" class="btn btn-secondary">Atras</button>
            <button id="<?= $id_button_next ?>" type="button" class="btn btn-primary">Continuar Reserva</button>
        </div>
        <?php
        return ob_get_clean();
    }

    private function checkbox_switch(string $name, bool $checked = false)
    {
        ob_start();
        ?>
        <div class="form-check form-switch d-flex justify-content-center" style="width: 100px">
            <input class="form-check-input" type="checkbox" role="switch" name="<?= $name ?>" <?= $checked ? 'checked' : '' ?>>
        </div>
        <?php
        return ob_get_clean();
    }

    private function extra_component(string $label, string $target, Component $compnent)
    {
        ?>
        <div class="d-flex justify-content-between align-items-center p-3">
            <div class="h-100">
                <span class="align-middle"><?= $label ?></span>
                <i class="bi bi-question-circle control-issue" data-target="<?= $target ?>" style="cursor: pointer;"></i>
            </div>
            <?= $compnent->compact(); ?>
        </div>
        <?php
    }
}
