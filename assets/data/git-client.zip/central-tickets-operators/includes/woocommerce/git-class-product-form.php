<?php
namespace CentralTicketsOperators;

use CentralTickets\Constants\TypeWayConstants;
use CentralTickets\ExternalConnection;

final class ProductForm
{
    private function __construct()
    {
    }

    public static function get_tabs()
    {
        return [
            'operator_producto' => [
                'label' => 'General',
                'target' => 'git_general_product_data',
                'class' => ['show_if_operator_external'],
                'priority' => 25,
            ]
        ];
    }

    public static function get_general_panel()
    {
        ?>
        <div id="git_general_product_data" class="panel woocommerce_options_panel">
            <div class="options_group">
                <?php
                $connection = new ExternalConnection;
                $products = $connection->get_products();
                $transports = $connection->get_transports();

                $options_product = [];
                $options_transport = [];
                $options_script = [];

                foreach ($products as $product) {
                    $options_product[$product['id']] = $product['title'];
                    $options_script[$product['id']] = $product['permalink'];
                }

                foreach ($transports as $transport) {
                    $options_transport[$transport['id']] = $transport['nicename'];
                }

                woocommerce_wp_select([
                    'id' => 'product_external',
                    'label' => 'Emparentar con producto externo',
                    'options' => $options_product,
                    'description' => 'Está disponible para mapear un cliente externo con un producto GIT.'
                ]);

                woocommerce_wp_select([
                    'id' => 'transport_parent',
                    'label' => 'Transporte con el que deseas operar',
                    'options' => $options_transport,
                    'description' => 'Elige uno de los transportes que se te fue asignado en el sistema GIT Central.'
                ]);

                ?>
                <a target="_blank" class="button button_secondary">Comprobar producto operable</a>
                <script>
                    jQuery(document).ready(function ($) {
                        const permalink = <?php echo json_encode($options_script); ?>;
                        function updateExternalLink() {
                            var productId = $('#product_external').val();
                            if (productId) {
                                var url = permalink[productId]; // Cambia esto a la URL correcta
                                $('.button.button_secondary').attr('href', url).show();
                            } else {
                                $('.button.button_secondary').hide();
                            }
                        }

                        $('#product_external').change(updateExternalLink);
                        updateExternalLink(); // Inicializa el enlace al cargar la página
                    });
                </script>
            </div>
        </div>
        <?php
    }

    public static function process_form(int $post_id)
    {
        update_post_meta($post_id, '_sale_price', 0);
        update_post_meta($post_id, '_regular_price', 1);
        update_post_meta($post_id, 'product_external', $_POST['product_external']);
        update_post_meta($post_id, 'transport_parent', $_POST['transport_parent']);
    }
}
