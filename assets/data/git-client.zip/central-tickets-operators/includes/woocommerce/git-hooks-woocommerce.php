<?php

use CentralTickets\Constants\PassengerConstants;
use CentralTickets\Constants\PriceExtraConstants;
use CentralTickets\Constants\TypeWayConstants;
use CentralTickets\ExternalConnection;
use CentralTickets\WooCommerce\FormProduct;
use CentralTicketsOperators\ProductForm;

add_filter('woocommerce_product_data_tabs', function ($tabs) {
    return array_merge($tabs, ProductForm::get_tabs());
});

add_action('woocommerce_product_data_panels', function () {
    ProductForm::get_general_panel();
});

add_action('woocommerce_process_product_meta_operator_external', function ($post_id) {
    ProductForm::process_form($post_id);
});

add_filter('woocommerce_get_price_html', function ($price_html, $product) {
    if ($product->get_type() !== 'operator_external') {
        return $price_html;
    }
    $id_product_external = (int) get_post_meta(
        $product->get_id(),
        'product_external',
        true
    );
    if ($id_product_external === '') {
        return '-';
    }
    $connector_external = new ExternalConnection;
    $external_product = $connector_external->get_product($id_product_external);
    $prices = $external_product['info']['prices'] ?? [];
    unset($prices[PriceExtraConstants::FLEXIBLE]);
    unset($prices[PriceExtraConstants::EXTRA]);
    $max = max(array_values($prices));
    $min = min(array_values($prices));
    $price_html = git_currency_format($min, false) . ' - ' . git_currency_format($max, false);
    return $price_html;

}, 10, 2);

add_action('woocommerce_single_product_summary', function () {
    global $product;
    if ($product->get_type() === 'operator_external') {
        if ($product->get_meta('enable_bookeable', true) === 'yes') {
            $form = new FormProduct($product);
            echo $form->compact();
        }
    }
}, 25);

add_action('wp_ajax_git_product_submit', function () {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'git_product_form')) {
        wp_send_json_error(['message' => 'Invalid nonce'], 403);
    }

    $connector_external = new ExternalConnection;
    $passengers = [];
    $route = null;
    $transport = null;
    $type_way = $_POST['type_away'] ?? TypeWayConstants::ONE_WAY;

    $pax = $_POST['pax'];
    $route = $connector_external->get_route($_POST['trip']['goes']['route']);
    $transport = $connector_external->get_transport($_POST['trip']['goes']['transport']);

    if ($route === null || $transport === null) {
        wp_safe_redirect(home_url());
        exit;
    }

    foreach ($_POST['passengers'] as $passenger) {
        $passengers[] = [
            'type' => $passenger['type'] ?? PassengerConstants::STANDARD,
            'name' => $passenger['name'] ?? '',
            'birthday' => $passenger['birthday'] ?? '',
            'nationality' => $passenger['nationality'] ?? '',
            'type_document' => $passenger['type_document'] ?? '',
            'data_document' => $passenger['data_document'] ?? '',
        ];
    }

    $product = wc_get_product($_POST['product'] ?? -1);
    if ($product === false || $product->get_type() !== 'operator_external') {
        wp_safe_redirect(home_url());
        exit;
    }
    $id_product_external = (int) get_post_meta(
        $product->get_id(),
        'product_external',
        true
    );
    if ($id_product_external <= 0) {
        wp_safe_redirect(home_url());
        exit;
    }
    $external_product = $connector_external->get_product($id_product_external);

    WC()->cart->add_to_cart(
        $_POST['product'],
        1,
        0,
        [],
        [
            'pax' => $pax,
            'route' => $route,
            'passengers' => $passengers,
            'transport' => $transport,
            'date_trip' => $_POST['trip']['goes']['date'],
            'prices' => $external_product['info']['prices'] ?? [
                PassengerConstants::KID => 0,
                PassengerConstants::RPM => 0,
                PassengerConstants::STANDARD => 0,
                PriceExtraConstants::EXTRA => 0,
            ],
        ],
    );

    if ($type_way === TypeWayConstants::DOUBLE_WAY) {

        $route = $connector_external->get_route($_POST['trip']['returns']['route']);
        $transport = $connector_external->get_transport($_POST['trip']['returns']['transport']);

        WC()->cart->add_to_cart(
            $_POST['product'],
            1,
            0,
            [],
            [
                'pax' => $pax,
                'route' => $route,
                'passengers' => $passengers,
                'transport' => $transport,
                'date_trip' => $_POST['trip']['returns']['date'],
                'prices' => $external_product['info']['prices'] ?? [
                    PassengerConstants::KID => 0,
                    PassengerConstants::RPM => 0,
                    PassengerConstants::STANDARD => 0,
                    PriceExtraConstants::EXTRA => 0,
                ],
            ],
        );
    }
    wp_safe_redirect(wc_get_cart_url());
    exit;
}, 25);

add_filter('woocommerce_get_item_data', function ($item_data, $cart_item) {
    if ($cart_item['data']->get_type() !== 'operator_external') {
        return $item_data;
    }
    $item_data[] = [
        'key' => 'Ruta',
        'value' => $cart_item['route']['origin']['name'] . ' » ' . $cart_item['route']['destiny']['name'],
    ];
    $item_data[] = [
        'key' => 'Viaje',
        'value' => git_date_format($cart_item['date_trip']) . ' - ' . git_time_format($cart_item['route']['departure_time']),
    ];
    $item_data[] = [
        'key' => 'Transporte',
        'value' => $cart_item['transport']['nicename'],
    ];
    $item_data[] = [
        'key' => 'Pax',
        'value' => sizeof($cart_item['passengers']) . ' Pasajero(s)',
    ];
    return $item_data;
}, 10, 2);

add_action('woocommerce_before_calculate_totals', function ($cart_object) {
    foreach ($cart_object->get_cart() as $cart_item) {
        $product = wc_get_product($cart_item['product_id']);
        if ($product->get_type() !== 'operator_external') {
            continue;
        }
        $prices = $cart_item['prices'] ?? [
            PassengerConstants::KID => 0,
            PassengerConstants::RPM => 0,
            PassengerConstants::STANDARD => 0,
            PriceExtraConstants::EXTRA => 0,
        ];
        $pax_kid = $cart_item['pax'][PassengerConstants::KID] ?? 0;
        $pax_rpm = $cart_item['pax'][PassengerConstants::RPM] ?? 0;
        $pax_extra = $cart_item['pax'][PriceExtraConstants::EXTRA] ?? 0;
        $pax_standard = $cart_item['pax'][PassengerConstants::STANDARD] ?? 0;
        $total = $pax_kid * $prices[PassengerConstants::KID] +
            $pax_rpm * $prices[PassengerConstants::RPM] +
            $pax_standard * $prices[PassengerConstants::STANDARD] +
            $pax_extra * $prices[PriceExtraConstants::EXTRA];
        foreach ($cart_item['transport']['services'] ?? [] as $service) {
            $total += $service['price'] / 100;
        }
        $cart_item['data']->set_price($total);
    }
});

add_action('woocommerce_checkout_create_order_line_item', function ($item, $cart_item_key, $values, $order) {
    if ($values['data']->product_type !== 'operator_external') {
        return;
    }
    $item->add_meta_data('Trayecto', $values['route']['origin']['name'] . ' » ' . $values['route']['destiny']['name'], true);
    $item->add_meta_data('Viaje', git_date_format($values['date_trip']), true) . ' ' . git_time_format($values['route']['departure_time']);
    $item->add_meta_data('Transporte', $values['transport']['nicename'], true);
    $item->add_meta_data('Pax', sizeof($values['passengers']) . ' Pasajero(s)', true);
    $item->add_meta_data('_type_product', 'operator_external', true);
    $item->add_meta_data('_original_data', serialize($values), true);
}, 10, 4);

add_action('woocommerce_thankyou', function ($order_id) {
    $order = wc_get_order($order_id);
    $items = $order->get_items();
    $data = [];

    foreach ($items as $item) {
        $type_product = $item->get_meta('_type_product');
        if ($type_product === 'operator_external') {
            $info = unserialize($item->get_meta('_original_data'));
            $data[] = $info;
        }
    }
    $connector_external = new ExternalConnection;

    foreach ($data as $info) {
        $pax = $info['pax'];
        $prices = $info['prices'];
        $price = $pax[PassengerConstants::KID] * $prices[PassengerConstants::KID] +
            $pax[PassengerConstants::RPM] * $prices[PassengerConstants::RPM] +
            $pax[PassengerConstants::STANDARD] * $prices[PassengerConstants::STANDARD] +
            $pax[PriceExtraConstants::EXTRA] * $prices[PriceExtraConstants::EXTRA];
        foreach ($info['transport']['services'] ?? [] as $service) {
            $price += $service['price'] / 100;
        }
        $ticket = [
            'total_price' => $price,
            'terminal' => home_url(),
            'route' => $info['route']['id'],
            'date_trip' => $info['date_trip'],
            'transport' => $info['transport']['id'],
            'passengers' => $info['passengers'],
            'customer_info' => [
                'firstname' => $order->get_billing_first_name(),
                'lastname' => $order->get_billing_last_name(),
                'email' => $order->get_billing_email(),
                'phone' => $order->get_billing_phone(),
            ],
            'host_url' => home_url()
        ];
        $connector_external->send_ticket_data($ticket);
    }

    $item->delete_meta_data('_type_product');
    $item->delete_meta_data('_original_data');
    $item->save();
}, 10, 1);