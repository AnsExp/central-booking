<?php

use CentralTickets\ExternalConnection;
use CentralTickets\PassengerForm;

defined('ABSPATH') || exit;

add_action("wp_ajax_git_submit_operator_code", function () {
    $code = $_POST['operator_code'] ?? null;

    if ($code === null) {
        set_transient(
            'git_operator_code_notice',
            '<p>Se requiere un código de operador.</p>',
            30
        );
        wp_redirect(wp_get_referer());
        exit;
    }

    $decoded = base64_decode($code);

    if (!$decoded) {
        set_transient(
            'git_operator_code_notice',
            [
                'status' => 'error',
                'message' => '<p>Código de operador no válido.</p>',
            ],
            30
        );
        wp_redirect(wp_get_referer());
        exit;
    }

    $payload = json_decode($decoded, true);

    if ($payload === null || !isset($payload['secret_key'], $payload['delivery_url'])) {
        set_transient(
            'git_operator_code_notice',
            [
                'status' => 'error',
                'message' => '<p>Código de operador no válido.</p>',
            ],
            30
        );
        wp_redirect(wp_get_referer());
        exit;
    }

    $key = $payload['secret_key'];
    $url = $payload['delivery_url'];

    $response = wp_remote_post($url, [
        'body' => json_encode(['secret_key' => $key]),
        'headers' => ['Content-Type' => 'application/json']
    ]);

    if ($response instanceof WP_Error) {
        set_transient(
            'git_operator_code_notice',
            [
                'status' => 'error',
                'message' => '<p>Error al vincular el código de operador.</p>',
            ],
            30
        );
        wp_redirect(wp_get_referer());
        exit;
    }
    $response_array = json_decode($response['body'], true);

    if ($response['response']['code'] >= 300) {
        set_transient(
            'git_operator_code_notice',
            [
                'status' => 'error',
                'message' => '<p>' . $response_array['message'] . '</p>',
            ],
            30
        );
        wp_redirect(wp_get_referer());
        exit;
    }

    update_option('git_partner_delivery_url', [
        'secret_key' => $response_array['secret_key'],
        'delivery_url' => $response_array['delivery_url']
    ]);

    set_transient(
        'git_operator_code_notice',
        [
            'status' => 'success',
            'message' => '<p>Se ha vinculado el código de operador correctamente.</p>',
        ],
        30
    );

    wp_redirect(wp_get_referer());
    exit;
});

add_action('admin_notices', function () {
    if ($code = get_transient('git_operator_code_notice')) {
        echo '<div class="notice notice-' . esc_attr($code['status']) . ' is-dismissible">' . $code['message'] . '</div>';
        delete_transient('git_operator_code_notice');
    }
});

add_action('wp_ajax_git_fetch_transports', function () {
    $external = new ExternalConnection();
    $transports = $external->get_transports_for_booking(
        $_POST['date_trip'] ?? (new DateTime('now'))->format('Y-m-d'),
        $_POST['schedule'] ?? 'morning',
        $_POST['name_zone_origin'] ?? '',
        $_POST['name_zone_destiny'] ?? ''
    );
    $transport_parent = $_POST['transport_parent'] ?? -1;
    foreach ($transports as $transport) {
        if ($transport['id'] == $transport_parent) {
            wp_send_json_success([$transport]);
        }
    }
    wp_send_json_error(['message' => 'No transports found']);
});

add_action('wp_ajax_nopriv_git_fetch_transports', function () {
    $external = new ExternalConnection();
    $transports = $external->get_transports_for_booking(
        $_POST['date_trip'] ?? (new DateTime('now'))->format('Y-m-d'),
        $_POST['schedule'] ?? 'morning',
        $_POST['name_zone_origin'] ?? '',
        $_POST['name_zone_destiny'] ?? ''
    );
    $transport_parent = $_POST['transport_parent'] ?? -1;
    foreach ($transports as $transport) {
        if ($transport['id'] == $transport_parent) {
            wp_send_json_success([$transport]);
        }
    }
    wp_send_json_error(['message' => 'No transports found']);
});

add_action('wp_ajax_nopriv_git_fetch_transports', function () {
    $external = new ExternalConnection();
    $transports = $external->get_transports_for_booking(
        $_POST['date_trip'] ?? (new DateTime('now'))->format('Y-m-d'),
        $_POST['schedule'] ?? 'morning',
        $_POST['name_zone_origin'] ?? '',
        $_POST['name_zone_destiny'] ?? ''
    );
    wp_send_json_success($transports);
});

add_action('wp_ajax_nopriv_git_passenger_form_html', function () {
    $passenger_count = $_POST['passenger_count'] = isset($_POST['passenger_count']) ? (int) $_POST['passenger_count'] : 1;
    $passenger_form = new PassengerForm($passenger_count);
    wp_send_json_success($passenger_form->compact());
});

add_action('wp_ajax_git_passenger_form_html', function () {
    $passenger_count = $_POST['passenger_count'] = isset($_POST['passenger_count']) ? (int) $_POST['passenger_count'] : 1;
    $passenger_form = new PassengerForm($passenger_count);
    wp_send_json_success($passenger_form->compact());
});

add_action('wp_ajax_nopriv_git_check_availability_for_passengers', function () {
    $route = isset($_POST['route_id']) ? (int) $_POST['route_id'] : 0;
    $transport = isset($_POST['transport_id']) ? (int) $_POST['transport_id'] : 0;
    $date_trip = isset($_POST['date_trip']) ? $_POST['date_trip'] : (new DateTime)->format('Y-m-d');
    $passenger_count = isset($_POST['passenger_count']) ? (int) $_POST['passenger_count'] : 1;
    $external = new ExternalConnection();
    $availability = $external->check_availability_transport(
        $date_trip,
        $route,
        $transport,
        $passenger_count,
    );
    wp_send_json_success($availability);
});

add_action('wp_ajax_git_check_availability_for_passengers', function () {
    $route = isset($_POST['route_id']) ? (int) $_POST['route_id'] : 0;
    $transport = isset($_POST['transport_id']) ? (int) $_POST['transport_id'] : 0;
    $date_trip = isset($_POST['date_trip']) ? $_POST['date_trip'] : (new DateTime)->format('Y-m-d');
    $passenger_count = isset($_POST['passenger_count']) ? (int) $_POST['passenger_count'] : 1;
    $external = new ExternalConnection();
    $availability = $external->check_availability_transport(
        $date_trip,
        $route,
        $transport,
        $passenger_count,
    );
    wp_send_json_success($availability);
});