<?php

use CentralTickets\Components\Component;
use CentralTickets\Constants\TransportConstants;
use CentralTickets\Constants\TypeWayConstants;

function git_get_text_by_type(string $type)
{
    return [
        TransportConstants::AERO => 'Aéreo',
        TransportConstants::LAND => 'Terrestre',
        TransportConstants::MARINE => 'Marítimo',
    ][$type] ?? $type;
}

function git_string_to_component(string $component): Component
{
    return new class ($component) implements Component {
        public function __construct(private readonly string $component)
        {
        }
        public function compact()
        {
            return $this->component;
        }
    };
}

function git_get_text_by_way(string $type)
{
    return [
        TypeWayConstants::ONE_WAY => 'Ida',
        TypeWayConstants::DOUBLE_WAY => 'Ida y vuelta',
        TypeWayConstants::ANY_WAY => 'Cualquiera',
    ][$type] ?? $type;
}

function git_currency_format($amount, bool $is_cent)
{
    if ($is_cent) {
        $amount /= 100;
    }
    return number_format($amount, 2, ',', '.') . '$';
}

function git_time_format(string $time)
{
    return date_format(date_create($time), 'H:i a');
}

function git_duration_format(string $time)
{
    list($hours, $minutes) = explode(":", $time);
    return sprintf("%02dh%02d", $hours, $minutes);
}

function git_date_format(string $date, bool $short = false)
{
    $months = [
        1 => 'enero',
        2 => 'febrero',
        3 => 'marzo',
        4 => 'abril',
        5 => 'mayo',
        6 => 'junio',
        7 => 'julio',
        8 => 'agosto',
        9 => 'septiembre',
        10 => 'octubre',
        11 => 'noviembre',
        12 => 'diciembre'
    ];

    $months_short = [
        1 => 'ene',
        2 => 'feb',
        3 => 'mar',
        4 => 'abr',
        5 => 'may',
        6 => 'jun',
        7 => 'jul',
        8 => 'ago',
        9 => 'sep',
        10 => 'oct',
        11 => 'nov',
        12 => 'dic'
    ];

    $date_obj = date_create($date);
    if ($date_obj === false) {
        return $date;
    }

    $day = date_format($date_obj, 'j');
    $month_num = (int) date_format($date_obj, 'n');
    $year = date_format($date_obj, 'Y');

    if ($short) {
        return "{$day} {$months_short[$month_num]}, {$year}";
    } else {
        return "{$day} de {$months[$month_num]}, {$year}";
    }
}

function git_datetime_format(string $datetime)
{
    $months = [
        1 => 'enero',
        2 => 'febrero',
        3 => 'marzo',
        4 => 'abril',
        5 => 'mayo',
        6 => 'junio',
        7 => 'julio',
        8 => 'agosto',
        9 => 'septiembre',
        10 => 'octubre',
        11 => 'noviembre',
        12 => 'diciembre'
    ];

    $datetime_obj = date_create($datetime);
    if ($datetime_obj === false) {
        return $datetime;
    }

    $day = date_format($datetime_obj, 'j');
    $month_num = (int) date_format($datetime_obj, 'n');
    $year = date_format($datetime_obj, 'Y');
    $time = date_format($datetime_obj, 'G:i');
    $ampm = date_format($datetime_obj, 'A') === 'AM' ? 'am' : 'pm';

    $hour = (int) date_format($datetime_obj, 'G');
    $minute = date_format($datetime_obj, 'i');

    if ($hour == 0) {
        $hour_12 = 12;
    } elseif ($hour > 12) {
        $hour_12 = $hour - 12;
    } else {
        $hour_12 = $hour;
    }

    $time_formatted = sprintf("%d:%s %s", $hour_12, $minute, $ampm);

    return "{$day} de {$months[$month_num]}, {$year} {$time_formatted}";
}

/**
 * Transforma una cadena a cualquier tipo de dato.
 * @param string $value Cadena a parsear.
 * @return mixed Valor parseado, puede ser bool, int, float, null, string o array.
 */
function git_unserialize(string $value): mixed
{
    $decoded = json_decode($value, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        return $decoded;
    }

    $unserialized = @unserialize($value);
    if ($unserialized !== false) {
        return $unserialized;
    }

    if ($value === 'true')
        return true;
    if ($value === 'false')
        return false;
    if ($value === 'null')
        return null;
    if (is_numeric($value)) {
        return strpos($value, '.') !== false ? (float) $value : (int) $value;
    }

    return $value;
}

/**
 * Serializa un valor para almacenarlo en la base de datos.
 * Convierte tipos complejos a JSON, y maneja strings, booleans y nulls adecuadamente.
 * @param mixed $value Valor a serializar. Puede ser un string, boolean, null, int, float o array.
 * @return bool|string Retorna el valor serializado como string. En caso de un error, retorna false.
 */
function git_serialize(mixed $value): string
{
    if (is_string($value)) {
        return $value;
    }

    if (is_bool($value)) {
        return $value ? 'true' : 'false';
    }

    if (is_null($value)) {
        return 'null';
    }

    if (is_scalar($value)) {
        return (string) $value;
    }

    return json_encode($value, JSON_UNESCAPED_UNICODE);
}