(function ($) {
    $(document).ready(function () {
        $('.git-row-action-link').each(function (index, element) {
            const $element = $(element);
            $element.on('click', function (event) {
                const target = $element.attr('href');
                const $targetContainer = $(target);
                const parentSelector = $targetContainer.data('parent');
                $(parentSelector)
                    .find('div.git-item-container')
                    .each(function (index, container) {
                        const $container = $(container);
                        if ($container.attr('id') === target.substring(1)) {
                            $container.toggleClass('hidden');
                        } else {
                            $container.addClass('hidden');
                        }
                    });
            });
        });
    });
})(jQuery);