import { domain } from "./domain.js";

export function queryRoutesByZonesName(zoneOrigin, zoneDestiny, type = 'marine') {
}

export function queryRoutesByLocations(zoneOrigin, zoneDestiny, type = 'marine') {
}