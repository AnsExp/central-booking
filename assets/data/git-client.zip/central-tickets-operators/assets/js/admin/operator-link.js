console.log(OperatorsLinkData);
const form = document.getElementById(OperatorsLinkData.elements.idForm);
const buttonSubmit = form.querySelector('button[type="submit"]');

form.addEventListener('submit', function (event) {
    const originalText = buttonSubmit.textContent;
    buttonSubmit.textContent = 'Generando...';
    buttonSubmit.disabled = true;
    event.preventDefault();
    const formData = new FormData(form);
    fetch(OperatorsLinkData.ajaxUrl, {
        method: 'POST',
        body: formData,
    }).then(response => response.json()).then(data => {
        buttonSubmit.textContent = originalText;
        buttonSubmit.disabled = false;
        document.getElementById('id_connector_key_container').innerHTML = data.data;
    });
});